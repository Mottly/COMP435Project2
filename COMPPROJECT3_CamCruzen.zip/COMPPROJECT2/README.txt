Cameron Cruzen - COMP 435 Project 2

CONTROLS:

WASD or ARROW KEYS to MOVE
SPACE to ATTACK

Move between levels and defeat enemies to increase your Health. Your score is also your health.